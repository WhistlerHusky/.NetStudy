﻿using System;

namespace SourceLinkTest
{
    public class SourceLinkRunner 
    {
        int _devicesCount = 100;

        public void Run()
        {
            Console.WriteLine("Debug");
        }
    }
}
