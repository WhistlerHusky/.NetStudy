﻿namespace AbpSourceLinkTest
{
    /// <summary>
    /// This class can be used as a base class for application services. 
    /// </summary>
    public abstract class SourceLinkTestApplicationService 
    {
        public static string[] CommonPostfixes = { "AppService", "ApplicationService" };

        /// <summary>
        /// Checks if current user is granted for a permission.
        /// </summary>
        /// <param name="permissionName">Name of the permission</param>
        protected virtual bool IsGranted(string permissionName)
        {
            return true;
        }
    }
}
